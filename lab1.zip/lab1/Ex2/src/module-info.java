/**
 * 
 */
/**
 * 
 */
module Lab1Ex2 {
}