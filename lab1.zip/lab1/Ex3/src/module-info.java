/**
 * 
 */
/**
 * 
 */
module lab1Ex3 {
}